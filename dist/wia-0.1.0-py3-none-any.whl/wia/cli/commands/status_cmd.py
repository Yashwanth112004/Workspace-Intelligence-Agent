"""CLI command for `wia status`."""

import click
from wia.cli.formatting import format_kv, format_error, format_header
from wia.services.status_service import StatusService


@click.command("status", help="Show workspace indexing status.")
@click.argument("path", type=click.Path(exists=False), required=False)
@click.pass_context
def status_cmd(ctx: click.Context, path: str | None) -> None:
    """Display current workspace index status and pending changes."""
    result = StatusService.get_status(target_path=path)

    if not result.success:
        click.echo(format_error(result.message), err=True)
        ctx.exit(1)

    data = result.data or {}
    click.echo(format_header("WIA Workspace Status"))
    click.echo(format_kv("Workspace", data.get("workspace_path", "")))

    if not data.get("is_indexed"):
        click.echo(format_kv("Status", click.style("Not Indexed", fg="yellow")))
        click.echo()
        click.echo("Run 'wia index' to index this workspace.")
        return

    click.echo(format_kv("Status", click.style("Indexed", fg="green")))
    click.echo(format_kv("Last Indexed", data.get("indexed_at", "")))
    click.echo(format_kv("Indexed Files", str(data.get("indexed_files_count", 0))))

    changes = data.get("changes", {})
    click.echo()
    click.echo(click.style("  Changes Since Last Index:", bold=True))
    click.echo(format_kv("Added", str(changes.get("added", 0)), indent=4))
    click.echo(format_kv("Modified", str(changes.get("modified", 0)), indent=4))
    click.echo(format_kv("Deleted", str(changes.get("deleted", 0)), indent=4))
    click.echo(format_kv("Unchanged", str(changes.get("unchanged", 0)), indent=4))
