"""CLI package initialization."""
