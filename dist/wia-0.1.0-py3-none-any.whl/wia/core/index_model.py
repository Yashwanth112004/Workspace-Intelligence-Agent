"""Workspace Index schema data model."""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any
import wia
from wia.constants import CURRENT_INDEX_SCHEMA_VERSION
from wia.core.metadata import FileRecord, IndexingStatus


@dataclass
class WorkspaceIndex:
    """Versioned schema model for persistent WIA workspace index state."""

    index_version: str = CURRENT_INDEX_SCHEMA_VERSION
    wia_version: str = field(default_factory=lambda: wia.__version__)
    workspace_path: str = ""
    indexed_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    files: dict[str, FileRecord] = field(default_factory=dict)
    languages: dict[str, int] = field(default_factory=dict)
    frameworks: list[str] = field(default_factory=list)
    stats: dict[str, Any] = field(
        default_factory=lambda: {
            "total_discovered": 0,
            "total_indexed": 0,
            "total_ignored": 0,
            "indexing_duration_seconds": 0.0,
        }
    )

    def get_indexed_files(self) -> list[FileRecord]:
        """Return list of active indexed file records."""
        return [
            f for f in self.files.values() if f.indexing_status == IndexingStatus.INDEXED
        ]

    def get_files_by_language(self, language: str) -> list[FileRecord]:
        """Return indexed files matching target language (case-insensitive)."""
        target = language.lower()
        return [
            f
            for f in self.get_indexed_files()
            if f.language.lower() == target
        ]

    def to_dict(self) -> dict[str, Any]:
        """Serialize WorkspaceIndex to dictionary for JSON persistence."""
        return {
            "index_version": self.index_version,
            "wia_version": self.wia_version,
            "workspace_path": self.workspace_path,
            "indexed_at": self.indexed_at,
            "files": {path: rec.to_dict() for path, rec in self.files.items()},
            "languages": self.languages,
            "frameworks": self.frameworks,
            "stats": self.stats,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkspaceIndex":
        """Construct WorkspaceIndex from deserialized JSON dictionary."""
        files_data = data.get("files", {})
        file_records = {
            path: FileRecord.from_dict(rec_dict)
            for path, rec_dict in files_data.items()
        }

        return cls(
            index_version=data.get("index_version", CURRENT_INDEX_SCHEMA_VERSION),
            wia_version=data.get("wia_version", wia.__version__),
            workspace_path=data.get("workspace_path", ""),
            indexed_at=data.get("indexed_at", datetime.now(timezone.utc).isoformat()),
            files=file_records,
            languages=data.get("languages", {}),
            frameworks=data.get("frameworks", []),
            stats=data.get("stats", {}),
        )
