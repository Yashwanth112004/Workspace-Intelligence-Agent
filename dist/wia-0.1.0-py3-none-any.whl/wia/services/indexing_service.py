"""Complete workspace indexing pipeline orchestrator."""

import time
from pathlib import Path
from wia.core.change_detector import ChangeDetector
from wia.core.config import WorkspaceConfig
from wia.core.discovery import FileDiscovery
from wia.core.filter import FileFilter
from wia.core.framework import FrameworkDetector
from wia.core.gitignore import GitignoreProcessor
from wia.core.hashing import FileHasher
from wia.core.index_model import WorkspaceIndex
from wia.core.language import LanguageDetector
from wia.core.metadata import FileRecord, IndexingStatus
from wia.core.validator import WorkspaceValidator
from wia.services.base import BaseService, ServiceResult
from wia.storage.repository import IndexRepository


class IndexingService(BaseService):
    """Orchestrates the 14-step WIA repository indexing pipeline."""

    @classmethod
    def index_workspace(
        cls, target_path: str | Path | None = None, force_reindex: bool = False
    ) -> ServiceResult[dict]:
        """Execute complete workspace indexing operation."""
        start_time = time.perf_counter()
        path = Path(target_path).resolve() if target_path else Path.cwd().resolve()

        # 1. Validate workspace
        val_result = WorkspaceValidator.validate(path)
        if not val_result.is_valid:
            return ServiceResult.fail(
                val_result.error_message or f"Invalid workspace path: {path}"
            )

        try:
            # 2. Load configuration
            config = WorkspaceConfig.load_from_workspace(path)

            # 3. Load previous index (unless force_reindex is specified)
            previous_index = (
                None if force_reindex else IndexRepository.load_index(path)
            )
            previous_records = previous_index.files if previous_index else {}

            # 4. Discover candidate files
            discovered = FileDiscovery.discover_files(path)

            # 5. Initialize Gitignore processor & File filter
            gi_processor = GitignoreProcessor(path)
            file_filter = FileFilter(config, gitignore_processor=gi_processor)

            current_records: dict[str, FileRecord] = {}
            ignored_count = 0

            # 6-8. Process discovered files: filter, metadata, hash, language
            for file in discovered:
                filter_res = file_filter.evaluate(file)

                if not filter_res.should_index:
                    ignored_count += 1
                    current_records[file.relative_path] = FileRecord(
                        relative_path=file.relative_path,
                        file_size=file.file_size,
                        modified_time=file.modified_time,
                        extension=Path(file.relative_path).suffix,
                        indexing_status=IndexingStatus.IGNORED,
                        exclusion_reason=filter_res.reason,
                    )
                    continue

                # Reprocessing optimization: if timestamp and path match previous record, check hash
                prev_rec = previous_records.get(file.relative_path)
                if (
                    prev_rec
                    and prev_rec.indexing_status == IndexingStatus.INDEXED
                    and prev_rec.modified_time == file.modified_time
                    and prev_rec.file_size == file.file_size
                ):
                    content_hash = prev_rec.content_hash
                else:
                    content_hash = FileHasher.hash_file(
                        file.absolute_path, algorithm=config.hash_algorithm
                    )

                language = LanguageDetector.detect_language(file.absolute_path)

                current_records[file.relative_path] = FileRecord(
                    relative_path=file.relative_path,
                    file_size=file.file_size,
                    modified_time=file.modified_time,
                    extension=Path(file.relative_path).suffix,
                    content_hash=content_hash,
                    language=language,
                    indexing_status=IndexingStatus.INDEXED,
                )

            # 9. Detect frameworks & tools
            detected_frameworks = FrameworkDetector.detect_frameworks(path)
            framework_names = [f.name for f in detected_frameworks]

            # 10. Detect incremental state changes
            change_summary = ChangeDetector.detect_changes(
                previous_records=previous_records, current_records=current_records
            )

            # 11. Calculate language breakdown stats
            lang_counts: dict[str, int] = {}
            for rec in current_records.values():
                if rec.indexing_status == IndexingStatus.INDEXED:
                    lang_counts[rec.language] = (
                        lang_counts.get(rec.language, 0) + 1
                    )

            duration = round(time.perf_counter() - start_time, 3)

            # 12. Build new WorkspaceIndex object
            new_index = WorkspaceIndex(
                workspace_path=str(path),
                files=current_records,
                languages=lang_counts,
                frameworks=framework_names,
                stats={
                    "total_discovered": len(discovered),
                    "total_indexed": len(current_records) - ignored_count,
                    "total_ignored": ignored_count,
                    "indexing_duration_seconds": duration,
                },
            )

            # 13. Persist new index atomically
            IndexRepository.save_index(path, new_index)

            # 14. Return structured summary payload
            payload = {
                "workspace_path": str(path),
                "total_discovered": len(discovered),
                "total_indexed": len(current_records) - ignored_count,
                "total_ignored": ignored_count,
                "changes": change_summary.counts,
                "languages": lang_counts,
                "frameworks": framework_names,
                "duration_seconds": duration,
            }

            return ServiceResult.ok(
                f"Indexed workspace '{path}' in {duration}s", data=payload
            )

        except Exception as err:
            return ServiceResult.fail(
                f"Indexing pipeline failed: {err}", error=err
            )
