# WIA — Workspace Intelligence Agent

> **AI-powered workspace intelligence for analyzing, understanding, and reporting on large software codebases.**

WIA (Workspace Intelligence Agent) is a **CLI-first software intelligence platform** designed to analyze large software repositories and build a structured **Workspace Knowledge Model**.

Unlike traditional AI coding assistants that primarily respond to developer prompts, WIA focuses on **understanding the software workspace itself**.

WIA analyzes source code, project structure, libraries, dependencies, architecture, Git history, security, configuration, and development environment. The analysis is performed **batch-by-batch and in parallel**, with results persisted locally so that large repositories can be analyzed efficiently and incrementally.

The generated results are presented through a **persistent HTML workspace report** that is updated as each batch completes.

---

# 🛠️ Phase 1 CLI Manual Testing & Verification Guide

### 1. Install WIA Package (One-Time Setup)
Navigate to the **WIA codebase directory** (where `pyproject.toml` is located) and run:

```bash
cd /path/to/Workspace-Intelligence-Agent
pip install -e .
```
*(Once installed, the `wia` command becomes globally available in your terminal).*

---

### 2. Verify WIA Installation
Run these from any terminal window:
```bash
wia --version
wia --help
```

---

### 3. Test WIA on Any Target Repository
Navigate to **ANY project repository** on your computer (for example, `cd C:\Users\pulig\OneDrive\Desktop\eth`):

```bash
# Navigate to target project
cd /path/to/target-repo

# Initialize WIA workspace (.wia folder)
wia init

# Index the target repository
wia index

# Check indexing status and pending changes
wia status

# List indexed files (optionally filter by language)
wia files
wia files --language python

# View workspace analytics and tech stack breakdown
wia info
```

---

# 🎯 Vision

WIA aims to answer:

> **"What is inside this software workspace, how does it work, what does it depend on, what problems exist, and what could be affected by future changes?"**

WIA is therefore not just an AI coding chatbot.

It is a **Workspace Intelligence Engine** with CLI, reporting, analysis, search, Q&A, and impact-analysis capabilities.

---

# ✨ Core Features

## 🔍 Full Workspace Analysis

WIA analyzes the repository across multiple dimensions:

* Repository structure
* Programming languages
* Frameworks
* Source files
* Classes and functions
* Symbols
* Imports and exports
* APIs and endpoints
* Modules and services
* Configuration files
* Environment configuration
* Build systems
* Libraries
* Dependencies
* Dependency relationships
* Git history
* Security
* Architecture
* Data flow
* Code relationships

---

## 📦 Library & Environment Intelligence

WIA identifies the technologies already present in the workspace.

It detects:

* Installed libraries
* Declared libraries
* Missing libraries
* Library versions
* Direct dependencies
* Transitive dependencies
* Package managers
* Runtime versions
* Framework versions
* Required development tools
* Build dependencies

Example:

```text
Environment Analysis

✓ Python 3.12
✓ Node.js 22
✓ React
✓ FastAPI
✓ PostgreSQL

Missing Dependencies
⚠ numpy

Version Conflicts
⚠ requests

package-A → requests >= 2.31
package-B → requests < 2.30
```

---

# ⚠️ Dependency & Library Conflict Detection

WIA detects problems in the project's dependency ecosystem.

It can identify:

* Version conflicts
* Incompatible dependencies
* Missing packages
* Duplicate dependencies
* Dependency cycles
* Unsupported runtime versions
* Framework incompatibilities
* Deprecated dependencies
* Lockfile inconsistencies
* Manifest/lockfile mismatches
* Conflicting package requirements

WIA reports:

```text
Problem
   ↓
Affected library
   ↓
Affected files/modules
   ↓
Reason
   ↓
Potential impact
   ↓
Suggested resolution
```

---

# 🏗️ Architecture Intelligence

WIA reconstructs the architecture from the actual codebase.

It identifies relationships such as:

```text
Application
    ↓
Modules
    ↓
Services
    ↓
Controllers / APIs
    ↓
Business Logic
    ↓
Repositories
    ↓
Database / External Services
```

WIA can identify:

* Modules
* Services
* APIs
* Components
* Data flow
* Dependencies
* Function relationships
* Call relationships
* Architectural boundaries
* Potential architectural issues

---

# 📊 Batch-Based Analysis

Large repositories should not be processed as one massive operation.

WIA divides the workspace into manageable analysis batches.

```text
Repository
     │
     ▼
Workspace Scanner
     │
     ▼
Batch Planner
     │
     ├── Batch 001
     ├── Batch 002
     ├── Batch 003
     ├── Batch 004
     └── ...
             │
             ▼
       Parallel Analysis
             │
             ▼
      Workspace Knowledge
             │
             ▼
       HTML Report
```

Each completed batch is persisted independently.

This allows WIA to:

* Process large repositories efficiently
* Show results before the entire analysis finishes
* Resume interrupted analysis
* Avoid repeating completed work
* Re-analyze only affected batches

---

# ⚡ Parallel Processing

Independent analysis tasks run in parallel.

```text
                 Orchestrator
                      │
       ┌──────────────┼──────────────┐
       ▼              ▼              ▼
 Code Analysis   Dependency      Git Analysis
       │          Analysis            │
       └──────────────┬──────────────┘
                      ▼
                Security Analysis
                      │
                      ▼
              Knowledge Engine
```

WIA uses local concurrency such as:

* `asyncio`
* `ProcessPoolExecutor`
* Parallel workers

The initial version is intentionally **local-first**.

Future versions can introduce distributed workers.

---

# ♻️ Incremental Analysis

WIA does not repeatedly analyze the entire repository.

It maintains local state and detects changes using:

* File hashing
* Modification tracking
* Dependency relationships
* Incremental AST analysis
* Persistent analysis results
* Cached embeddings
* Dependency-aware invalidation

Example:

```text
Initial Analysis
      ↓
10,000 files analyzed
      ↓
Results cached
      ↓
Developer changes 20 files
      ↓
WIA detects changes
      ↓
Only affected batches are reprocessed
```

This is one of the core requirements for supporting large codebases.

---

# 📑 Persistent HTML Workspace Report

WIA generates a **persistent HTML report/dashboard**.

```text
.wia/
└── report/
    ├── index.html
    ├── batches/
    │   ├── batch-001.json
    │   ├── batch-002.json
    │   ├── batch-003.json
    │   └── ...
    └── assets/
```

The report is updated as analysis progresses.

### Example

```text
Batch 001     ✅ Complete
Batch 002     ✅ Complete
Batch 003     🔄 Processing
Batch 004     ⏳ Pending
Batch 005     ⏳ Pending
```

When the user reloads the HTML page:

* Completed batches remain visible
* Processing batches show their current state
* Pending batches remain pending
* Failed batches display errors
* Newly completed batches become available
* Previously completed batches are not regenerated

The HTML report **never starts analysis itself**.

It only reads the persisted WIA analysis state.

---

# 📋 Generated Reports

WIA generates reports including:

```text
Workspace Overview
Technology Stack
Environment
Code Structure
Architecture
Dependencies
Dependency Conflicts
Security
Git Intelligence
Project Health
Batch Analysis
```

Example:

```text
.wia/report/

├── index.html
├── workspace.json
├── architecture.json
├── dependencies.json
├── conflicts.json
├── security.json
├── environment.json
└── batches/
```

---

# 💬 Codebase Q&A

Q&A is **one capability of WIA**, not the main purpose.

Once the workspace has been analyzed, users can query the Workspace Knowledge Model.

```bash
wia ask "How does authentication work?"
```

```bash
wia ask "What depends on PaymentService?"
```

```bash
wia ask "Where is the database configured?"
```

```bash
wia ask "What could break if I modify UserService?"
```

WIA retrieves relevant workspace information rather than repeatedly analyzing the entire repository.

---

# 🎯 Impact Analysis

WIA can determine potential effects of modifying a component.

```bash
wia impact UserService
```

Example:

```text
UserService
    │
    ├── UserController
    ├── AuthenticationService
    ├── OrderService
    ├── UserRepository
    └── 14 dependent functions

Impact Level: HIGH
```

Impact analysis combines:

* Symbol relationships
* Dependency relationships
* Call relationships
* Module relationships
* Git history
* Workspace knowledge

---

# 🧠 Workspace Knowledge Model

WIA maintains a structured representation of the software workspace.

```text
Workspace
│
├── Files
├── Symbols
├── Modules
├── Services
├── APIs
├── Dependencies
├── Libraries
├── Configuration
├── Git History
├── Security Findings
└── Relationships
```

This model becomes the foundation for:

* Reports
* Search
* Q&A
* Impact analysis
* Architecture analysis
* Future VS Code integration

---

# 🏗️ Architecture

```text
                         WIA CLI
                            │
                            ▼
                   ┌────────────────┐
                   │  Orchestrator  │
                   │ Batch Scheduler│
                   └───────┬────────┘
                           │
                    Workspace Scanner
                           │
                           ▼
                     Batch Planner
                           │
          ┌────────────────┼────────────────┐
          │                │                │
          ▼                ▼                ▼
    Code Intelligence  Dependency      Git Intelligence
        Worker          Worker             Worker
          │                │                │
          └────────────────┼────────────────┘
                           │
                    Security Worker
                           │
                           ▼
              Workspace Knowledge Engine
              ┌────────────┼────────────┐
              │            │            │
            SQLite       FAISS        Cache
              │            │            │
              └────────────┼────────────┘
                           │
                           ▼
                 Architecture Agent
                           │
                           ▼
                    RAG Context
                           │
                           ▼
                    Reasoning Agent
                           │
              ┌────────────┴────────────┐
              ▼                         ▼
        Report Generator           Q&A / Search
              │                         │
              ▼                         ▼
       HTML Workspace Report       CLI Response
```

---

# 🤖 WIA Agents & Workers

WIA uses specialized analysis workers and AI agents.

### 1. Scanner Worker

Responsible for:

* Repository scanning
* File discovery
* `.gitignore`
* File hashing
* Language detection
* Framework detection
* Batch creation

### 2. Code Intelligence Worker

Responsible for:

* Tree-sitter AST analysis
* Symbols
* Classes
* Functions
* Imports
* Exports
* Code relationships
* LSP/SCIP integration

### 3. Dependency Worker

Responsible for:

* Package manifests
* Lockfiles
* Libraries
* Versions
* Dependency graphs
* Missing dependencies
* Dependency conflicts

### 4. Git Intelligence Worker

Responsible for:

* Commits
* Branches
* Authors
* File history
* Change frequency
* Hotspots

### 5. Security Worker

Responsible for:

* Static analysis
* Secret detection
* Vulnerability patterns
* Security findings
* Risk classification

### 6. Architecture Agent

Responsible for:

* Architecture interpretation
* Module relationships
* Service relationships
* APIs
* Data flow
* Architecture summaries

### 7. Knowledge/RAG Engine

Responsible for:

* Indexing
* Embeddings
* Semantic retrieval
* Context construction
* Workspace knowledge

### 8. Reasoning Agent

Responsible for:

* Complex reasoning
* Impact analysis
* Codebase Q&A
* Architecture reasoning
* Recommendations

Deterministic analysis is performed by workers wherever possible. LLM agents are used primarily for tasks that require reasoning.

---

# 🖥️ CLI

WIA is **CLI-first**.

## Initialize

```bash
wia init
```

## Analyze

```bash
wia analyze
```

## Check status

```bash
wia status
```

## Open HTML report

```bash
wia report
```

or:

```bash
wia report --open
```

## Search

```bash
wia search "authentication"
```

## Ask

```bash
wia ask "How does authentication work?"
```

## Architecture

```bash
wia architecture
```

## Dependencies

```bash
wia dependencies
```

## Security

```bash
wia security
```

## Git intelligence

```bash
wia git
```

## Explain

```bash
wia explain src/services/UserService.py
```

## Impact analysis

```bash
wia impact UserService
```

---

# ⚙️ Technology Stack

## Core

* Python 3.12+
* Typer
* Rich
* Pydantic
* asyncio
* ProcessPoolExecutor
* uv

## Code Intelligence

* Tree-sitter
* LSP
* SCIP

## Security

* Semgrep

## Knowledge & Storage

* SQLite
* FAISS
* Local filesystem cache
* In-memory relationship graph

## AI

* LLM abstraction layer
* RAG
* Embeddings
* Architecture reasoning
* Report generation

## Version Control

* Git
* GitPython / native Git

---

# 🚀 Future Technology

The first version is deliberately **local and lightweight**.

Future WIA versions can introduce:

```text
PostgreSQL
pgvector / Qdrant
Neo4j
Redis
Apache Kafka
Distributed Workers
NVIDIA NIM
GPU acceleration
Kubernetes
VS Code Extension
Web Dashboard
```

These technologies are not required for the initial CLI MVP.

---

# ⚡ Performance Strategy

WIA is designed around five principles:

```text
INCREMENTAL
    +
PARALLEL
    +
BATCHED
    +
CACHED
    +
SELECTIVE AI
```

WIA should **never send an entire large repository to an LLM**.

Instead:

```text
Repository
     ↓
Scan
     ↓
Hash
     ↓
Batch
     ↓
Parallel Analysis
     ↓
Persist Results
     ↓
Retrieve Relevant Information
     ↓
AI Reasoning Only When Required
```

This reduces:

* Processing time
* Memory usage
* LLM token usage
* Repeated computation
* Analysis cost

---

# 📁 Project Structure

A proposed implementation structure:

```text
wia/
│
├── cli/
│   ├── commands/
│   └── main.py
│
├── core/
│   ├── orchestrator.py
│   ├── scheduler.py
│   ├── batch.py
│   └── models.py
│
├── scanner/
│   ├── scanner.py
│   ├── hasher.py
│   └── detector.py
│
├── analyzers/
│   ├── code/
│   ├── dependency/
│   ├── git/
│   └── security/
│
├── knowledge/
│   ├── database.py
│   ├── vector_store.py
│   ├── graph.py
│   └── cache.py
│
├── agents/
│   ├── architecture.py
│   └── reasoning.py
│
├── rag/
│   ├── retriever.py
│   ├── embeddings.py
│   └── context.py
│
├── reports/
│   ├── generator.py
│   ├── templates/
│   └── assets/
│
└── tests/
```

---

# 🔄 Analysis Lifecycle

```text
wia analyze
     │
     ▼
Scan Workspace
     │
     ▼
Detect Changes
     │
     ▼
Create Batches
     │
     ▼
Run Workers in Parallel
     │
     ▼
Persist Batch Results
     │
     ▼
Update Workspace Knowledge
     │
     ▼
Update HTML Report
     │
     ▼
Continue Remaining Batches
     │
     ▼
Final Workspace Report
```

If analysis is interrupted:

```text
Completed Batches → Keep
Running Batch     → Re-evaluate
Pending Batches   → Resume
Unchanged Files   → Skip
```

---

# 🔐 Local-First Design

The initial WIA CLI is designed to work locally wherever possible.

Benefits:

* Faster analysis
* Reduced network dependency
* Persistent local knowledge
* Better privacy
* Lower recurring cost
* Suitable for large repositories

AI providers can be configured independently through the WIA model abstraction.

---

# 🎯 Project Goal

The initial goal of WIA is to create a **fast, intelligent, batch-based CLI capable of analyzing large software repositories and generating a continuously updated HTML workspace report**.

The first release should successfully provide:

```bash
wia init
wia analyze
wia status
wia report
wia search
wia ask
wia architecture
wia dependencies
wia security
wia impact
```

The CLI is the foundation for the future WIA ecosystem:

```text
                 WIA Intelligence Engine
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
         CLI          VS Code       Web Dashboard
                         │
                         ▼
                 Developer Workflow
```

> **WIA doesn't just answer questions about your codebase.
> WIA analyzes your workspace, builds its intelligence, generates reports, detects problems, and lets you reason over the system.**
